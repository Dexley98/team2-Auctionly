import React from "react";

class AddItemForm extends React.Component {
  state = {
    itemName: "",
    itemDescription: "",
    startPrice: "",
    buyPrice: "",
    itemImage: ""
  };

  onSubmit = e => {
    // add firebase
  };

  render() {
    return (
      <form>
        <input
          placeholder="Item Name"
          value={this.state.itemName}
          onChange={e => this.setState({ itemName: e.target.value })}
        />
        <input
          placeholder="Item Description"
          value={this.state.itemDescription}
          onChange={e => this.setState({ itemDescription: e.target.value })}
        />
        <input
          placeholder="Starting Bid Price"
          value={this.state.startPrice}
          onChange={e => this.setState({ startPrice: e.target.value })}
        />
        <input
          placeholder="Buy Now Price"
          value={this.state.buyPrice}
          onChange={e => this.setState({ buyPrice: e.target.value })}
        />
        <input
          type="file"
          // insert label
          value={this.state.itemImage}
          onChange={e => this.setState({ itemImage: e.target.value })}
        />
        <button onClick={() => this.onSubmit()}>Submit</button>
      </form>
    );
  }
}
export default AddItemForm;
