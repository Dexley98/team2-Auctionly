import React from "react";

class AdminMain extends React.Component {
  render() {
    return <h1>Auctionly Admin</h1>;
    // add two buttons one for reports one to add an item
  }
}

export default AdminMain;
