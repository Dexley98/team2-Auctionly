import React from "react";
import ReactDOM from "react-dom";
import AddItemForm from "./Components/Tools/AddItemForm";

// add if statement for if the user is logged in and has a statis of admins
ReactDOM.render(<AddItemForm />, document.getElementById("root"));
